package com.example.mobile_app_cal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
